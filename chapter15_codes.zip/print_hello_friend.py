#print_hello_friend.py
from datetime import datetime
print(datetime.now())
print("G'day Mate!") 
