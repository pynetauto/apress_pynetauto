import time
import paramiko

ip_addresses = ["192.168.183.10", "192.168.183.20", "192.168.183.101", "192.168.183.102", "192.168.183.133"]

username = "pynetauto"
password = "cisco123"

ssh_client = paramiko.SSHClient()
ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
for ip in ip_addresses:
    ssh_client.connect(hostname=ip, username=username, password=password)
    print("Connected to " + ip + "\n")
    remote_connection = ssh_client.invoke_shell()

    output1 = remote_connection.recv(3000) # Catches and removes the login prompt output
    # print(output1.decode('ascii')) # remove hash to print the login prompt message

    remote_connection.send("configure terminal\n")
    remote_connection.send("clock timezone AEST +10\n") # Change to your timezone
    remote_connection.send("clock summer-time AEST recurring\n") # Change to your timezone summertime
    remote_connection.send("exit\n")
    time.sleep(1)
    remote_connection.send("clock set 15:15:00 12 Jan 2021\n") # Change to current time
    remote_connection.send("copy running-config startup-config\n")
    remote_connection.send("end\n")
    output2 = remote_connection.recv(65535)
    print((output2).decode('ascii'))
    time.sleep(1)
    ssh_client.close()
    print("-"*60)
