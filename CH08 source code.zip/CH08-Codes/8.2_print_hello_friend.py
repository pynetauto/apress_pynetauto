from datetime import datetime
print(datetime.now())
print("G'day Mate!")
