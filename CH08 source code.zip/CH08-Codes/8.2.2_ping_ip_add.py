#!/usr/bin/python3

import os
import datetime 

with open("/home/pynetauto/icmp_pinger/ip_addresses.txt", "r") as ip_addresses:
    print(datetime.datetime.now()) 
    for ip_add in ip_addresses:
        ip = ip_add.strip()
        rep = os.system('ping -c 3 ' + ip)
        if rep == 0:
            print(f"{ip} is reachable.")
            print("-"*80)
        else:
            print(f"{ip} is either offline or icmp is filtered.")
            print("-"*80)

print("All task completed.")