#!/usr/bin/python3

import os
import datetime

def icmp_pinger(ip):
    rep = os.system('ping -c 3 ' + ip)
    if rep == 0:
        print(f"{ip} is reachable.")
    else:
        print(f"{ip} is either offline or icmp is filtered. Exiting.")
        exit()
    print("-"*80)
