from scapy.all import *

ips = ['192.168.30.10', '192.168.30.20', '192.168.30.101', '192.168.30.102', '192.168.30.130', '192.168.30.133', '192.168.30.153', '192.102.0.1', '192.102.0.40']


def UpDown():
    for ip in ips:
        while True:
            print("Testing connection to : ", ip)
            icmp = IP(dst=ip)/ICMP()
            resp = sr1(icmp,timeout=5)
            if resp == None:
                print("Down")
                time.sleep(3)
            else:
                print("Up")
                time.sleep(10)
UpDown()
