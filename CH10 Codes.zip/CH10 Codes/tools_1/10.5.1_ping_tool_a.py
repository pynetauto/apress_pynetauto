#10.5.1_ping_tool_a.py

import os

device_list = ['192.168.183.111', '192.168.183.222']

for ip in device_list:
    if len(ip) != 0:
        print(f'Sending icmp packets to {ip}')
        resp = os.system(f'ping -c 4 {ip}')
        if resp == 0:
            print(f'{ip} is on the network.')
            print('-'*80)
        else:
            print(f'{ip} is unreachable.')
            print('-'*80)
    else:
        exit()
