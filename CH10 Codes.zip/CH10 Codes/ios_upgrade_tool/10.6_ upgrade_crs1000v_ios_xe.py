import socket
import os
import time
import pandas as pd
import re
from getpass import getpass
import os.path
import hashlib
from netmiko import ConnectHandler, SCPConn
from netmiko.ssh_exception import  NetMikoTimeoutException
import difflib


t = time.mktime(time.localtime()) # Timer start to measure script running time

"""
Step 9. From 10.5.10_post_check_b.py.
Check SSH port 22 and then log back in. Then complete the post-upgrade verfication check.
This script compares before and after running configurations to validate the success
of IOS XE upgrade for your devices.
"""

def check_port_22_post(ip, port, device, t1):
    retry = 90 # Try 90 times
    delay = 5 # 5 seconds wait
    def isOpen(ip, port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(3)
        try:
            s.connect((ip, int(port)))
            s.shutdown(socket.SHUT_RDWR)
            return True # The statements after the return statements are not executed.
        except:
            return False
        finally:
            s.close()
    # Retry 90 times until port is in open state.
    for i in range(retry):
        if isOpen(ip, port):
            print(ip + " is back online.")
            t2 = time.mktime(time.localtime()) - t1
            print(f"{ip}'s reload time : {0} seconds".format(t2))
            print(f"Logging back into {ip} to perform post-reload tasks.")
            print("Please wait...")
            #When port 22 is open, start postreload_check here.
            print(ip)
            net_connect = ConnectHandler(**device)
            print(f'*** {ip} is back online.')
            print("-"*80)

            # [Post-reload] Capture configuration
            print(f"{ip} [Post-reload] Capture configuration")
            file14 = open(ip + '_showver_post.txt', 'w+')
            net_connect.send_command("terminal length 0")
            showver_postreload = net_connect.send_command("show version")
            print("* [Post-reload] Capturing 'show version'")
            file14.write(showver_postreload)
            file14.close()
            # Successful upgrade will print IP and correct system boot image name.
            p99= re.compile(r'System image file is ".+[?=\"]')
            m99 = p99.findall(showver_postreload)
            print(f"! {ip}'s {m99}.")
            time.sleep(2)
            file15 = open(ip + '_showrun_post.txt', 'w+')
            showrun_postreload = net_connect.send_command("show running-config")
            print("* [Post-reload] Capturing 'show running-config'")
            file15.write(showrun_postreload)
            file15.close()
            time.sleep(2)
            file16 = open(ip + '_showint_post.txt', 'w+')
            showint_postreload = net_connect.send_command("show ip interface brief")
            print("* [Post-reload] Capturing 'show ip interface brief'")
            file16.write(showint_postreload)
            file16.close()
            time.sleep(2)
            file17= open(ip + '_showroute_post.txt', 'w+')
            showroute_postreload = net_connect.send_command("show ip route")
            print("* [Post-reload] Capturing 'show ip route'")
            file17.write(showroute_postreload)
            file17.close()
            time.sleep(2)

            # Compare pre and post configurations to create four html files
            showver_pre = "showver_pre"
            showver_post = "showver_post"
            showver_pre_lines = open(ip+ '_showver_pre.txt').readlines() #convert to strings first for comparision
            time.sleep(1)
            showver_post_lines = open(ip+ '_showver_post.txt').readlines() #convert to strings first for comparision
            time.sleep(1)
            # Note, four arguments required in HtmlDiff function
            difference = difflib.HtmlDiff(wrapcolumn=70).make_file(showver_pre_lines, showver_post_lines, showver_pre, showver_post)
            difference_report = open(ip + "_show_ver_comparison.html", "w+")
            difference_report.write(difference) # Write the differences to the difference_report
            difference_report.close()
            time.sleep(1)
            showrun_pre = "showrun_pre"
            showrun_post = "showrun_post"
            showrun_pre_lines = open(ip+ '_showrun_pre.txt').readlines() #Convert to strings first for comparision
            time.sleep(1)
            showrun_post_lines = open(ip+ '_showrun_post.txt').readlines() #Convert to strings first for comparision
            time.sleep(1)
            difference = difflib.HtmlDiff(wrapcolumn=70).make_file(showrun_pre_lines, showrun_post_lines, showrun_pre, showrun_post)
            difference_report = open(ip + "_show_run_comparison.html", "w+")
            difference_report.write(difference) # Write the differences to the difference_report
            difference_report.close()
            time.sleep(1)
            showint_pre = "showint_pre"
            showint_post = "showint_post"
            showint_pre_lines = open(ip+ '_showint_pre.txt').readlines() #Convert to strings first for comparision
            time.sleep(1)
            showint_post_lines = open(ip+ '_showint_post.txt').readlines() #Convert to strings first for comparision
            time.sleep(1)
            difference = difflib.HtmlDiff(wrapcolumn=70).make_file(showint_pre_lines, showint_post_lines, showint_pre, showint_post)
            difference_report = open(ip + "_show_int_comparison.html", "w+")
            difference_report.write(difference) # Write the differences to the difference_report
            difference_report.close()
            time.sleep(1)
            showroute_pre = "showroute_pre"
            showroute_post = "showroute_post"
            showroute_pre_lines = open(ip+ '_showroute_pre.txt').readlines() #Convert to strings first for comparision
            time.sleep(1)
            showroute_post_lines = open(ip+ '_showroute_post.txt').readlines() #Convert to strings first for comparision
            time.sleep(1)
            difference = difflib.HtmlDiff(wrapcolumn=70).make_file(showroute_pre_lines, showroute_post_lines, showroute_pre, showroute_post)
            difference_report1 = open(ip + "_show_route_comparison.html", "w+")
            difference_report1.write(difference) # Write the differences to the difference_report1
            difference_report1.close()
            time.sleep(1)
            print("-"*80)
            break
        else:
            print(f'{ip} is still reloading. Please wait...')
            time.sleep(delay)

"""
Step 1. From 10.5.2_get_cred_c.py
Get network administrator ID and password, also prompt
for enable secret and give user option to select yes or no.
p1 : Between 5-30 characters long, starting with an alphabet &
finishes with an alphabet or a number
p2 : Between 8-50 characters long, starting with an alphabet &
finishes with any characters
"""

def get_secret(p2):
    global secret
    resp = input("Is secret same as password? (y/n) : ")
    print("-"*80)
    resp = resp.lower()
    if resp == "yes" or resp == "y":
        secret = pwd
    elif resp == "no" or resp == "n":
        secret = None
        while not secret:
            secret = getpass("Enter the secret : ")
            while not p2.match(secret):
                secret = getpass(r"*Enter the secret : ")
            secret_verify = getpass("Confirm the secret : ")
            if secret != secret_verify:
                print("!!! secret do not match. Please try again.")
                print("-"*80)
                secret = None
    else:
        get_secret(p2)

def get_credentials():
    p1 = re.compile(r'^[a-zA-Z][a-zA-Z0-9_-]{3,28}[a-zA-Z0-9]$')
    p2 = re.compile(r'^[a-zA-Z].{7,49}')
    global uid
    uid = input("Enter Network Admin ID : ")
    while not p1.match(uid):
        uid = input(r"*Enter Network Admin ID : ")
    global pwd
    pwd = None
    while not pwd:
        pwd = getpass("Enter Network Admin PWD : ")
        while not p2.match(pwd):
            pwd = getpass(r"*Enter Network Admin PWD : ")
        pwd_verify = getpass("Confirm Network Admin PWD : ")
        if pwd != pwd_verify:
            print("!!! Network Passwords do not match. Please try again.")
            print("-"*80)
            pwd = None
    # Trigger get_secret function to run
    get_secret(p2)
    return uid, pwd, secret
# Trigger get_Credential function to run
get_credentials()

"""
Step 2. From 10.5.3_read_info_h.py
Read the content of devices_info.csv file and convert the values
into two lists. device_list to be used as information feeder to the script
device_list_netmiko to be used as netmiko friendly dictionary items for SSH connection
"""

def read_info(uid, pwd, secret):
    df = pd.read_csv(r'./devices_info.csv')
    number_of_rows = len(df.index)
    # Read the values and save as a list, read column as df and save it as a list
    devicename = list(df['devicename'])
    device = list(df['device'])
    devicetype = list(df['devicetype'])
    ip = list(df['host'])
    newios = list(df['newios'])
    newiosmd5 = list(df['newiosmd5'])
    # Append the items and convert to a list, device_list
    global device_list # For 10.5.4_validate_md5_b
    device_list = []
    for index, rows in df.iterrows():
        device_append = [rows.devicename, rows.device, \
        rows.devicetype, rows.host, rows.newios, rows.newiosmd5]
        device_list.append(device_append)
    # Using device_list, create a netmiko friendly list device_list_netmiko
    global device_list_netmiko
    device_list_netmiko = []
    i = 0
    for x in device_list:
        if len(x) != 0: # As long as number of items in device_list is not 0 (empty)
            i += 1
            name = f'device{str(i)}'
            devicetype, host = x[2], x[3]
            device = {
            'device_type': devicetype,
            'host': host,
            'username': uid,
            'password': pwd,
            'secret': secret,
            }
            device_list_netmiko.append(device)
# Trigger read_info function to run
read_info(uid, pwd, secret)

"""
Step 3. From 10.5.1_ping_tool_f.py and 10.5.1_ping_tool_f_tools.py
Perform connectivity tests, first using ICMP ping, Second, check port 22
Also, seperate the ips with open port 22, if port 22 is closed, then test port 23
create three files containing the result of the reachability tests
"""

def test_connectivity(device_list_netmiko):
    f1 = open('reachable_ips_ssh.txt',  'w+')
    f2 = open('reachable_ips_telnet.txt', 'w+')
    f3 = open('unreachable_ips.txt', 'w+')
    for device in device_list_netmiko:
        ip = device['host'].strip()
        print(ip)
        resp = os.system('ping -c 4 ' + ip)
        if resp == 0:
            for port in range (22, 23):
                destination = (ip, port)
                try:
                    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                        s.settimeout(3)
                        connection = s.connect(destination)
                        print(f"{ip} {port} open")
                        print("-"*80)
                        f1.write(f"{ip}\n")
                except:
                    print(f"{ip} {port} closed")
                    f3.write(f"{ip} {port} closed\n")
                    for port in range (23, 24):
                        destination = (ip, port)
                        try:
                            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                                s.settimeout(3)
                                connection = s.connect(destination)
                                print(f"{ip} {port} open")
                                print("-"*80)
                                f2.write(f"{ip}\n")
                        except:
                            print(f"{ip} {port} closed")
                            print("-"*80)
                            f3.write(f"{ip} {port} closed\n")
        else:
            print(f"{ip} unreachable")
            print("-"*80)
            f3.write(f"{ip} unreachable\n")
    f1.close()
    f2.close()
    f3.close()
# Trigger test_connectivity function to run
test_connectivity(device_list_netmiko)

"""
Step 4. From 10.5.4_validate_md5_b.py
Validate the MD5 value of new IOS file on the Python Server against
the value you have provided on csv file. Must be validated before moving on.
"""

def validate_md5(device_list):
    for x in device_list:
        print(x[3], x[0], x[1], x[2])
        newios = x[4]
        newiosmd5 = str(x[5].lower()).strip()
        print(newiosmd5)
        newiosmd5hash = hashlib.md5()
        file = open(f'/home/pynetauto/ch10/new_ios/{newios}', 'rb')
        content = file.read()
        newiosmd5hash.update(content)
        newiosmd5server = newiosmd5hash.hexdigest()
        print(newiosmd5server.strip())
        global newiossize
        newiossize = round(os.path.getsize(f'/home/pynetauto/ch10/new_ios/{newios}')/1000000, 2)
        print(newiossize, "MB")
        if newiosmd5server == newiosmd5:
            print("MD5 values matched!")
            print("-"*80)
        else:
            print("Mismatched MD5 values. Exit")
            print("-"*80)
            exit()
    return newiossize
# Trigger validate_md5 function to run
validate_md5(device_list)

"""
Step 5. From 10.5.5_check_flash_b.py
Checks available flash size on the router
"""

def check_flash(device_list_netmiko, newiossize):
    for device in device_list_netmiko:
        ip = str(device['host'])
        net_connect = ConnectHandler(**device)
        net_connect.send_command("terminal length 0")
        showdir = net_connect.send_command("dir")
        #showflash = net_connect.send_command("show flash:") # For switches
        time.sleep(2)
        p1 = re.compile("\d+(?=\sbytes\sfree\))")
        m1 = p1.findall(showdir)
        flashfree = ((int(m1[0])/1000000))
        print(f"{ip} Free flash size : ", flashfree, "MB")
        print("-"*80)
        if flashfree < (newiossize * 1.5):
            print(f"Not enough space on {ip}'s flash! Exiting")
            print("!"*80)
            exit()
        else:
            print(f"{ip} has enough space for new IOS.")
            print("-"*80)
# Trigger check_flash function to run
check_flash(device_list_netmiko, newiossize)

"""
Step 6. From 10.5.7_ios_upload_a.py
First, check aaa configuration requirements, if not met, exit for correct configuration.
Second, check if 'ip scp enable' is enabled for SCP file transfer. Enable ip scp.
Third, upload IOS file to the router, then disable ip scp.
"""

def ios_upload(device_list_netmiko, device_list):
    i = 0
    for device in device_list_netmiko:
        device_x = device_list[i]
        newios = device_x[4] # Call out newios value
        newiosmd5 = device_x[5] # Call out newiosmd5 value
        i += 1

        s_newios = f'/home/pynetauto/ch10/new_ios/{newios}'
        print("*"*80)
        #print(device)
        ip = str(device['host'])
        print(f'{ip} beginning IOS XE upgrade.')
        username = str(device['username'])
        net_connect = ConnectHandler(**device)
        net_connect.send_command("terminal length 0")
        showrun = net_connect.send_command("show running-config")
        check_priv15 = (f'username {username} privilege 15')
        aaa_authenication = "aaa authentication login default local enable"
        aaa_authorization = "aaa authorization exec default local"
        if check_priv15 in showrun:
            print(f"{username} has level 15 privilege - OK")
            if aaa_authenication in showrun:
                print("check_aaa_authentication - OK")
                if aaa_authorization in showrun:
                    print("check_aaa_authorization - OK")
                else:
                    print("aaa_authorization - FAILED ")
                    exit()
            else:
                print("aaa_authentication - FAILED ")
                exit()
        else:
            print(f"{username} has not enough privilege - FAILED")
            exit()

        net_connect.enable(cmd='enable 15')
        net_connect.config_mode()
        net_connect.send_command('ip scp server enable')
        net_connect.exit_config_mode()
        time.sleep(1)
        print("New IOS uploading in progress! Please wait…")
        scp_conn = SCPConn(net_connect)
        scp_conn.scp_transfer_file(s_newios, newios)
        scp_conn.close()
        time.sleep(1)
        net_connect.config_mode()
        net_connect.send_command('no ip scp server enable')
        net_connect.exit_config_mode()

        """
        Step 7. From 10.5.8_verify_md5.py
        Fourth, verify MD5 value of new IOS on the router flash, then compare it with server side MD5 value.
        """

        try:
            locate_newios = net_connect.send_command(f"show flash: | in {newios}")
            if newios in locate_newios:
                result = net_connect.send_command("verify /md5 flash:{} {}".format(newios,newiosmd5))
                print(result)
                p1 = re.compile(r'Verified')
                p2 = re.compile(r'[a-fA-F0-9]{31}[a-fA-F0-9]')
                verified = p1.findall(result)
                newiosmd5flash = p2.findall(result)
                if verified:
                    result = True
                    print("MD5 values MATCH! Continue")
                    print("MD5 of new IOS on Server : ",newiosmd5)
                    print("MD5 of new IOS on flash  : ",newiosmd5flash[0])
                    print("-"*80)
                else:
                    result = False
                    print("MD5 values DO NOT MATCH! Exiting.")
                    print("-"*80)
                    exit()
            else:
                print("No new IOS found on router’s flash. Continue to next device…")
                print("-"*80)
        except (NetMikoTimeoutException):
            print (f'Timeout error to : {ip}')
            print("-"*80)
            continue
        except unknown_error:
            print ('Unknow error occured : ' + str(unknown_error))
            print("-"*80)
            continue

        """
        Step 8. From 10.5.9_reload_yesno_b.py
        Fifth, give the user a chance to review the result and let him/her decide if he wants to reload the device.
        This can be removed to fully automate this process, but this is included to demonstrate how interactive
        session works. If 'Y", reload now, if "n", reload later.
        Sixth, change the boot system command to boot into new IOS on the flash:/ Save configuration.
        """

        yes_list = ['yes', 'y']
        no_list = ['no', 'n']
        print("!"*80)
        print("Note: Devices will be reloaded one at a time.")
        resp = input(f"Do you want to reload {ip} now? (y/n)? ").lower()
        if resp in yes_list:
            print("Reloading devices")
            #net_connect = ConnectHandler(**device)
            net_connect.enable(cmd='enable 15')
            config_commands1 = ['no boot system', 'boot system flash:/' + newios, 'do write memory']
            output = net_connect.send_config_set(config_commands1)
            print (output)
            net_connect.send_command('terminal length 0\n')
            show_boot = net_connect.send_command('show boot\n')
            show_dir = net_connect.send_command('dir\n')
            if newios not in show_dir:
                print('Unable to locate new IOS on the flash:/. Exiting.')
                print("-"*80)
                exit()
            elif newios not in show_boot:
                print('Boot system was not correctly configured. Exiting.')
                print("-"*80)
                exit()

            # Seventh, if boot commands are correct, capture another running backups of device for comparison.
            elif newios in show_boot and newios in show_dir:
                try:
                    print(f'Found {newios} in show boot')
                    print("-"*80)
                    print(f"{ip} [Pre-reload] Capture configuration")
                    net_connect.send_command("terminal length 0")
                    time.sleep(1)
                    with open(f'{ip}_showver_pre.txt', 'w+') as f1:
                        print("* [Pre-reload] Capturing 'show version'")
                        showver_pre = net_connect.send_command("show version")
                        f1.write(showver_pre)
                    time.sleep(1)
                    with open(f'{ip}_showrun_pre.txt', 'w+') as f2:
                        print("* [Pre-reload] Capturing 'show running-config'")
                        showrun_pre = net_connect.send_command("show running-config")
                        f2.write(showrun_pre)
                    time.sleep(1)
                    with open(f'{ip}_showint_pre.txt', 'w+') as f3:
                        print("* [Pre-reload] Capturing 'show ip interface brief'")
                        showint_pre = net_connect.send_command("show ip interface brief")
                        f3.write(showint_pre)
                    time.sleep(1)
                    with open(f'{ip}_showroute_pre.txt', 'w+') as f4:
                        print("* [Pre-reload] Capturing 'show ip route'")
                        showroute_pre = net_connect.send_command("show ip route")
                        f4.write(showroute_pre)
                    time.sleep(1)
                    print("-"*80)

                    t1 = time.mktime(time.localtime()) # To measure time elapsed for reload

                    # Eighth, initiate the device reload
                    print(f"{ip} is now reloading.")
                    net_connect.send_command('reload', expect_string='[confirm]')
                    net_connect.send_command('yes')
                    net_connect.send_command('\n')
                    print("-"*80)


                    # If you remove "y" or "n" prompt, when reloading is initiated, the server will generate
                    # OSError, then you have to use this code to catch the OSError to run the code continueously.
                    # If using the interactive as in this example, then it will produce EoFError, so leave this
                    # code as is

                # except OSError:
                    # print("***Device is now reloading. This may take 2-5 minutes.")
                    # time.sleep(45)
                    # print("-"*80)
                    # port = 22
                    # check_port_22_post(ip, port, device)
                    # print("-"*80)

                except EOFError:
                    print("***Device is now reloading. This may take 2-5 minutes.")
                    time.sleep(60)
                    print("-"*80)
                    port = 22
                    # Trigger check_port_22_post function for check port 22 and post check
                    check_port_22_post(ip, port, device, t1)
                    print("-"*80)
        # If chosen 'n', break out of the operation
        elif resp in no_list:
            print("You have chosen to reload the devices later. Exiting the applicaton.")
            break
        print("*"*80)
# Trigger ios_upload main function
ios_upload(device_list_netmiko, device_list)

"""
Optionally.
Rename ios_upload() function as main() and you can use this to trigger the function.
if __name__ == "__main__":
  main()
"""

print("Completed new IOS verification.")
print("All tasks completed successfully!")

tt = time.mktime(time.localtime()) - t # Timer finish to measure script running time
print("Total time taken : {0} seconds".format(tt)) # Informational