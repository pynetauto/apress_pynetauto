# # Follow this exercise in Python IDLE
# from datetime import datetime
# IOS_rel_date = '12-Jul-17'
# x = IOS_rel_date.replace('-', ' ')
# y = datetime.strptime(x, '%d %b %y')

# datetime.datetime(2017, 7, 12, 0, 0)
# y.date() datetime.date(2017, 7, 12)
# y_day = y.date()

# datetime.today()
# datetime.datetime(2020, 4, 15, 11, 56, 3, 370515)
# datetime.today().date()
# datetime.date(2020, 4, 15)
# t_day = datetime.today().date()
# delta = t_day - y_day
# print(delta.days)

# years = round(((delta.days)/365), 2)

# Reiterated and reduced version of example 1:
from datetime import datetime
x = IOS_rel_date.replace('-', ' ')
y_day = (datetime.strptime(x, '%d %b %y')).date()
t_day = datetime.today().date()
delta = t_day - y_day
years = round(((delta.days)/365), 2)
print(years)


