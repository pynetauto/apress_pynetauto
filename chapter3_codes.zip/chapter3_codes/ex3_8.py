import sys
sys.path.append('C:\\Users\\brendan\\Documents\\')
import ex_96.py as ask

ask