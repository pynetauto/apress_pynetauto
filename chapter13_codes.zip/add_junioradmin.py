#!/usr/bin/env python3

import getpass
import telnetlib
import time  # imports time module

user = input("Enter your username: ")
password = getpass.getpass()

# Open ip_addresses.txt to read IP addresses
file = open("ip_addresses.txt") # Open and read an external file

for ip in file: # loop through read information
    print("Now configuring : " + ip) # Task beginning statement
    HOST = (ip.strip()) # Strips any white spaces
    tn = telnetlib.Telnet(HOST) # Use read IP to log into a single device

    tn.read_until(b"Username: ")
    tn.write(user.encode('ascii') + b"\n")
    if password:
        tn.read_until(b"Password: ")
        tn.write(password.encode('ascii') + b"\n")

    time.sleep(1) # Adds 1 second pause for device to respond
    # Configure a new user with privilege 3, allow show running-config # comment
    tn.write(b"conf t\n") # Enter configuration mode
    tn.write(b"username junioradmin privilege 3 password cisco321\n") # Configur                                                                             e new pri 3 user
    tn.write(b"privilege exec all level 3 show running-config\n") # Allow show r                                                                             unning-config command
#    tn.write(b"file privilege 3\n") # give access to file, For routers only
    print("Added a new privilege 3 user") # Task ending statement

    tn.write(b"end\n")
    tn.write(b"exit\n")
    print(tn.read_all().decode('ascii'))