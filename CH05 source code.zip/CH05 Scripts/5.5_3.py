 import re
 
 expr = 'Our team \scored three goals\\'
 p2 = re.compile(r'\\scored')
 m = p2.findall(expr)
 print(m)
 n = m[0]

 for x in n:
    print(x, end=")


