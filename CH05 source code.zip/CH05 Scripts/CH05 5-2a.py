import re

data = '''
cisco ISR4351/K9 (2RU) processor with 1687137K/6147K bytes of memory.
Processor board ID FDO3132B2Z4
3 Gigabit Ethernet interfaces
31 Serial interfaces
1 Channelized E1/PRI port
32768K bytes of non-volatile configuration memory.
4194304K bytes of physical memory.
3223551K bytes of flash memory at bootflash:.

Configuration register is 0x2102
'''

# Only match Cisco router model
x = re.findall("[A-Z]{3}\d{4}[/]\w+", data)
print(x)