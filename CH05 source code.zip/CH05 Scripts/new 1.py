import re

re.findall('^S.+sh$', 'Start to finish')
re.findall('\AS.+sh$', 'Start to finish')