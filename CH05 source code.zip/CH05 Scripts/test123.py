import re

#A. Match only single line examples
print(re.findall('^B.+d$', 'Beginning to end'))
#['Start to finish']

print(re.findall('\AB.+d$', 'Beginning to end'))
#['Start to finish']


#B. Match multiple lines but MULTILINE option not enabled examples
print(re.findall('^B.+d$', 'Beginning to end\nBusy street end\nBeer nuts and almond'))
#

print(re.findall('\AB.+d$', 'Beginning to end\nBusy street end\nBeer nuts and almond'))
#

#C. Match multiple lines with MULTILINE option enabled (^ and \A with re.M) examples
print(re.findall('^B.+d$', 'Beginning to end\nBusy street end\nBeer nuts and almond', re.M))
#['Start to finish', 'Special fish', 'Super fresh']

print(re.findall('\AB.+d$', 'Beginning to end\nBusy street end\nBeer nuts and almond', re.M))
#['Start to finish']


#D. \Z with ^ and \A with re.M examples
print(re.findall('^B.+d\Z', 'Beginning to end\nBusy street end\nBeer nuts and almond', re.M))
#['Super fresh']

print(re.findall('\AB.+d\Z', 'Start to finish\nSpecial fish\nSuper fresh', re.M))
#

