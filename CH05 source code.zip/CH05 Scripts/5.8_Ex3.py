import re
expr = '''Juniper router, HP switch, Palo Alto firewall,\
 Juniper router, HP switch, Palo Alto firewall, \
 Juniper router, HP switch, Palo Alto firewall, \
 Juniper router, HP switch, Palo Alto firewall, \
 Juniper router, HP switch, Palo Alto firewall, \
 Juniper router, HP switch, Palo Alto firewall and Arista router'''
p = re.compile('HP|Juniper|Arista')
print(p.subn('Cisco', expr))
