import os  # Import os and re modules
import re

stream = os.popen('snmpwalk -v3  -l authPriv -u SNMPUser1 -a SHA -A "AUTHPass1"  -x AES -X "PRIVPass1" 192.168.183.10 1.3.6.1.4.1.9.9.109.1.1.1.1.5') # SNMPwalk from previous chapter modified
output = stream.read() # Read output
print(output)

p1 = re.compile(r"(?:Gauge32: )(\d+)") # Use re positive lookbehind and match the digit
m1 = p1.findall(output) # Match the CPU utilization value (digit) in output

cpu_util_value = int(m1[0]) # Index itme 0 in the list and convert to an integer
print(pu_util_value) # print the integer
