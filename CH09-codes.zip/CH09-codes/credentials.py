account_sid = "2d8ee3a2ee22e8684e6f3d4eca2b8" # Twilio Account SID
auth_token = "3e8502a3dd3a2d006913c937a6" # Twilio Authorization Token
my_smartphone = "+61498765432" # Your country code and smartphone number
twilio_trial = "+16076003338" # Your Twilio trial number
