import matplotlib.pyplot as plt
import pandas as pd

device_uptime = {'Lab-SW4': 6.87, 'Lab-sw3': 6.87, 'LAB-SW1': 12.23, 'lab-sw2': 10.22, 'LAB-R1': 12.2, 'lab-r2': 10.65}

df = pd.DataFrame(list(device_uptime.items()),columns = ['host','uptime'])

#print(df)

df.plot(kind='bar',x='host',y='uptime')
plt.show()
