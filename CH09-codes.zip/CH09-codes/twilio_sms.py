from twilio.rest import Client # Import required twilio module
from credentials import account_sid, auth_token, my_smartphone, twilio_trial # import information from credentials.py file

client = Client(account_sid, auth_token) # Create a variable

my_message = f" High CPU utilization notice, LAB-R1 has reached 90% CPU utilization. # Write a SMS message to send

message = client.messages.create \
                (body=my_message, from=twilio_trial, to=my_smartphone) # Send SMS message

print(message.sid) # Print sent message SID 
