import getpass
import telnetlib

# 03 Add loopback 5
tn = telnetlib.Telnet("20.20.20.1")
tn.write("pynetauto".encode('ascii') + b"\n")
tn.write("cisco123".encode('ascii') + b"\n")
tn.write(b"configure terminal\n")
tn.write(b"interface loopback 5\n")
tn.write(b"ip address 5.5.5.5 255.255.255.255\n")
tn.write(b"end\n")
tn.write(b"exit\n")
print(tn.read_all().decode('ascii'))

# 04 show ip interface brief
tn = telnetlib.Telnet("20.20.20.1")
tn.write("pynetauto".encode('ascii') + b"\n")
tn.write("cisco123".encode('ascii') + b"\n")
tn.write(b"show ip interface brief\n")
tn.write(b"exit\n")
print(tn.read_all().decode('ascii'))
