import time
from netmiko import ConnectHandler, SCPConn
# Converted the list of dictionaries back to each variables

# From 10.5.3
s_newios = "/home/pynetauto/ch10/new_ios/csr1000v-universalk9.16.09.06.SPA.bin"
d_newios = "csr1000v-universalk9.16.09.06.SPA.bin"
newiosmd5 = "77878ae6db8e34de90e2e3e83741bf39"

device1 = {
    'device_type': 'cisco_xe',
    'host': '192.168.183.111',
    'username': 'pynetauto',
    'password': 'cisco123',
    'secret': 'cisco123'
}
device2 = {
    'device_type': 'cisco_xe',
    'host': '192.168.183.222',
    'username': 'pynetauto',
    'password': 'cisco123',
    'secret': 'cisco123'
}

devices_list = [device1, device2]

for device in devices_list:
    print(device)
    ip = str(device['host'])
    username = str(device['username'])
    net_connect = ConnectHandler(**device)
    net_connect.send_command("terminal length 0")
    showrun = net_connect.send_command("show running-config")
    check_priv15 = (f'username {username} privilege 15')
    aaa_authenication = "aaa authentication login default local enable"
    aaa_authorization = "aaa authorization exec default local"
    if check_priv15 in showrun:
        print(f"{username} has level 15 privilege - OK")
        if aaa_authenication in showrun:
            print("check_aaa_authentication - OK")
            if aaa_authorization in showrun:
                print("check_aaa_authorization - OK")
            else:
                print("aaa_authorization - FAILED ")
                exit()
        else:
            print("aaa_authentication - FAILED ")
            exit()
    else:
        print(f"{username} has not enough privilege - FAILED")
        exit()

    net_connect.enable(cmd='enable 15')
    net_connect.config_mode()
    net_connect.send_command('ip scp server enable')
    net_connect.exit_config_mode()
    time.sleep(1)
    print("New IOS uploading in progress! Please wait…")
    scp_conn = SCPConn(net_connect)
    scp_conn.scp_transfer_file(s_newios, d_newios)
    scp_conn.close() ######
    time.sleep(1)
    net_connect.config_mode()
    net_connect.send_command('no ip scp server enable')
    net_connect.exit_config_mode()
    print("-"*80)
