from netmiko import ConnectHandler
import re
from netmiko.ssh_exception import  NetMikoTimeoutException
from datetime import datetime

d_newios = "csr1000v-universalk9.16.09.06.SPA.bin"
newiosmd5 = "77878ae6db8e34de90e2e3e83741bf39"

device1 = {
    'device_type': 'cisco_xe',
    'host': '192.168.183.111',
    'username': 'pynetauto',
    'password': 'cisco123',
    'secret': 'cisco123',
    'global_delay_factor': 2
}
device2 = {
    'device_type': 'cisco_xe',
    'host': '192.168.183.222',
    'username': 'pynetauto',
    'password': 'cisco123',
    'secret': 'cisco123',
    'global_delay_factor': 2
}

devices_list = [device1, device2]

for device in devices_list:
    print(device)
    ip = str(device['host'])
    try:
        net_connect = ConnectHandler(**device)
        net_connect.send_command("terminal length 0")
        locate_newios = net_connect.send_command(f"show flash: | in {d_newios}")
        if d_newios in locate_newios:
            result = net_connect.send_command("verify /md5 flash:{} {}".format(d_newios,newiosmd5))
            print(result)
            net_connect.disconnect()
            p1 = re.compile(r'Verified')
            p2 = re.compile(r'[a-fA-F0-9]{31}[a-fA-F0-9]')
            verified = p1.findall(result)
            newiosmd5flash = p2.findall(result)
            if verified:
                result = True
                print("-"*80)
                print("MD5 values MATCH! Continue")
                print("MD5 of new IOS on Server : ",newiosmd5)
                print("MD5 of new IOS on flash  : ",newiosmd5flash[0])
                print("-"*80)
            else:
                result = False
                print("-"*80)
                print("MD5 values DO NOT MATCH! Exiting.")
                print("-"*80)
                exit()
        else:
            print("No new IOS found on router’s flash. Continue to next device…")
            with open("./error_logs.txt", "a+") as f:
                now = datetime.now()
                f.write(f"{now} No new IOS found on {ip}'s flash.\n")
            print("-"*80)
    except (NetMikoTimeoutException):
        print (f'Timeout error to : {ip}')
        print("-"*80)
        continue
    except unknown_error:
        print ('Unknow error occured : ' + str(unknown_error))
        print("-"*80)
        continue

print("Completed new IOS verification.")
