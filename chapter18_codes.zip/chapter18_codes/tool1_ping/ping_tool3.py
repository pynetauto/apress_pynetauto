# 10.5.1_ping_tool_c.py

import os

device_list = ['10.10.10.1',  '192.168.183.111', '192.172.1.33',  '192.168.183.222']

# reachable_ips = []
f1 = open('reachable_ips.txt',  'w+')
# unreachable_ips = []
f2 = open('unreachable_ips.txt', 'w+')

for ip in device_list:
    if len(ip) != 0:
        print(f'Sending icmp packets to {ip}')
        resp = os.system('ping -c 3 ' + ip)
        if resp == 0:
            #reachable_ips.append(ip)
            f1.write(f'{ip}\n')
            print('-'*80)
        else:
            #unreachable_ips.append(ip)
            f2.write(f'{ip}\n')
            print('-'*80)
    else:
        exit()

f1.close()
f2.close()