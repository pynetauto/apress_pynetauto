import time
from netmiko import ConnectHandler

# This is borrowed from 10.5.3_read_info_g.py result
devices_list =[
{
    'device_type': 'cisco_xe',
    'host': '192.168.183.111',
    'username': 'pynetauto',
    'password': 'cisco123',
    'secret': 'cisco123'
},
{
    'device_type': 'cisco_xe',
    'host': '192.168.183.222',
    'username': 'pynetauto',
    'password': 'cisco123',
    'secret': 'cisco123'
}]

for device in devices_list:
    net_connect = ConnectHandler(**device)
    net_connect.send_command("terminal length 0")
    showdir = net_connect.send_command("dir")
    #showflash = net_connect.send_command("show flash:")
    print(showdir)
    print("-"*80)
    time.sleep(2)
