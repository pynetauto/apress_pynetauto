from time import asctime, sleep
print(asctime())
sleep(10)
print(asctime())
