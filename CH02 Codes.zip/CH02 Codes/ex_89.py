import sys
file = 'C://Users//brendan//Documents//test.txt'
try:
    with open (file) as test_file:
        for line in test_file:
            print(line.strip())
except:
    print('Could not open {}'. format(file))
    sys.exit(1)