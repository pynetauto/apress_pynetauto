import getpass
def get_pwd():
    username = input('Enter username : ')
    password = getpass.getpass()
    print(username)
    print(password)

# get_pwd()
