name = input('Plese enter your name: ')
print('Hi, ', name)