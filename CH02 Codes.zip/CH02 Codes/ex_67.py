# ex_67.py
dialing_code = {'England': '+44', 'Greece': '+30', 'Italy': '+39', 'Spain': '+34', 'France': '+33'}
for code in dialing_code:
    print('The country code for {0} is {1}.'. format (code, dialing_code [code]))
