x, y, z
print (x, y, z)
y, z, x

