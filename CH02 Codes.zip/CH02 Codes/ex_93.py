print('Plese enter your name: ')
name = input()
print('Thank you, ', name)