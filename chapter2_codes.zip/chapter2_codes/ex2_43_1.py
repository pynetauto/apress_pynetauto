# ex_43_1.py
bread = ['bagels', 'baguette', 'ciabatta', 'crumpet'] 

try:
    crumpet_index = bread.index ('crumpet') 
except:
   crumpet_index = 'No crumpet bread was found.' 
   print(crumpet_index)