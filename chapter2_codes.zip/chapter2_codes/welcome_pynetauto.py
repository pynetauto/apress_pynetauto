print("Welcome to Python Network Automation")
