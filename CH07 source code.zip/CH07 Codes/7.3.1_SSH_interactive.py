import paramiko

ip_addresses = ["192.168.183.10", "192.168.183.20", "192.168.183.101", "192.168.183.102", "192.168.183.133"]

username = "pynetauto"
password = "cisco123"

ssh_client = paramiko.SSHClient()
ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

for ip in ip_addresses:
    ssh_client.connect(hostname=ip, username=username, password=password)
    print("Connected to " + ip + "\n")
    remote_connection = ssh_client.invoke_shell()
    remote_connection.send("configure terminal\n")
    remote_connection.send("clock timezone AEST +10\n")
    remote_connection.send("clock summer-time AEST recurring\n")
    remote_connection.send("exit\n")
    remote_connection.send("clock set 21:45:00 10 Aug 2020\n")
    remote_connection.send("copy running-config startup-config\n")
    remote_connection.send("end\n")
    output = remote_connection.recv(65535)
    print((output).decode('ascii'))
    ssh_client.close()
