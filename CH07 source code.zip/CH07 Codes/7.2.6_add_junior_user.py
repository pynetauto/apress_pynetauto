# 7.2.6_add_junior_user.py

#!/usr/bin/env python3.8

import getpass
import telnetlib

user = input("Enter your username: ")
password = getpass.getpass()

# Open ip_addresses.txt to read IP addresses
file = open("ip_addresses.txt")

for ip in file:
    print("Now configuring : " + ip)
    HOST = (ip.strip())
    tn = telnetlib.Telnet(HOST)

    tn.read_until(b"Username: ")
    tn.write(user.encode('ascii') + b"\n")
    if password:
        tn.read_until(b"Password: ")
        tn.write(password.encode('ascii') + b"\n")

    # Configure a new user with privilege 3, allow show running-config
    tn.write(b"conf t\n")
    tn.write(b"username junioradmin privilege 3 password cisco321\n")
    tn.write(b"privilege exec all level 3 show running-config\n")
    tn.write(b"file privilege 3\n")
    print("Added a new privilege 3 user")
    
    tn.write(b"end\n")
    tn.write(b"exit\n")
    print(tn.read_all().decode('ascii'))