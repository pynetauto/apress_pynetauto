import  socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

ip_addresses = ["192.168.183.10", "192.168.183.20", "192.168.183.101", "192.168.183.102", "192.168.183.133"]

for ip in ip_addresses:
    for port in range (22, 24):
        dest = (ip, port)

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(3)
                connection = s.connect(dest)
                print(f"on {ip}, port {port} is open!")
        except:
            print(f"On {ip}, port {port} is closed.")
