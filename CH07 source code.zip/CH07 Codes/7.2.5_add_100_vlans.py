# 7.2.5_add_100_vlans.py

#!/usr/bin/env python3.8

import getpass
import telnetlib

# HOSTS is a list with IP addresses of two switches
HOSTS = ["192.168.183.101", "192.168.183.102"]
user = input("Enter your username: ")
password = getpass.getpass()

# Use for loop to loop through the switch IPs
# The rest of the script have been indented  to run under this block
for HOST in HOSTS:
    print("SWITCH IP : " + HOST)
    tn = telnetlib.Telnet(HOST)

    tn.read_until(b"Username: ")
    tn.write(user.encode('ascii') + b"\n")
    if password:
        tn.read_until(b"Password: ")
        tn.write(password.encode('ascii') + b"\n")

    # Configure 100 VLANs with names using 'for ~ in range' loop
    tn.write(b"conf t\n")
    # Use for n in range (starting vlan, ending vlan, (optional-stepping not used))
    for n in range (700, 800):
        tn.write(b"vlan " + str(n).encode('UTF-8') + b"\n")
        tn.write(b"name PYTHON_VLAN_" + str(n).encode('UTF-8') + b"\n")

    tn.write(b"end\n")
    tn.write(b"exit\n")
    print(tn.read_all().decode('ascii'))
