import  socket

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

dest = ("192.168.183.10", 22)
port_open = sock.connect_ex(dest)

# open returns int 0, closed returns an integer based on port number
if port_open == 0:
    print(port_open)
    print("On ", {dest[0]}, "port is open.")
else:
    print(port_open)
    print("On ", {dest[0]}, "port is closed.")
sock.close()